"""
Определить, какое число в массиве встречается чаще всего
"""
import random
arr = [random.randint(1, 15) for _ in range(10)]


def count_frequency(orig):
    frequency = {i: 0 for i in range(1, 16)}
    for i in orig:
        frequency[i] += 1
    return frequency


def search_most_frequent(data):
    num = 0
    result = 0
    for i in range(1, 16):
        if data[i] >= result:
            result = data[i]
            num = i
    return num


print(f'Изначальный массив:')
print(*arr, sep=' ')
print(f'Наиболее встречаемое число: {search_most_frequent(count_frequency(arr))}')
