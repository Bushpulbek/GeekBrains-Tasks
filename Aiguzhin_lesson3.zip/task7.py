"""
В одномерном массиве целых чисел определить два наименьших элемента.
Они могут быть как равны между собой (оба минимальны), так и различаться.
"""
import random
arr = random.sample(range(1,100), 10)


def find_two_min(data):
    first_min = data[0]
    second_min = data[1]
    for i in data[2:]:
        if i < first_min:
            if first_min < second_min:
                second_min = first_min
            first_min = i
        elif first_min < i < second_min:
            second_min = i
    return [first_min, second_min]


print('Массив:')
print(*arr, sep=' ')
print('Два наименьших элемента:')
print(*find_two_min(arr), sep=' ')
