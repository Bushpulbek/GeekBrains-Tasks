"""
В массиве найти максимальный отрицательный элемент. Вывести на экран его значение и позицию в массиве
"""
import random
array = random.sample(range(-99, 100), 10)


def search_max_below(data):
    index = 0
    result = data[0]
    for i, item in enumerate(data):
        if item < 0 and abs(item) > abs(result):
            result = item
            index = i
    return [index, result]


print(f'Массив: {" ".join(map(str, array))}')
print(f'Индекс максимального отрицательного числа и само число: {" ".join(map(str, search_max_below(array)))}')
