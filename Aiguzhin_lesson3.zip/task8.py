"""
Матрица 5x4 заполняется вводом с клавиатуры, кроме последних элементов строк.
Программа должна вычислять сумму введенных элементов каждой строки и записывать ее в последнюю ячейку строки.
В конце следует вывести полученную матрицу.
"""
lines = 5
columns = 4
matrix = [[0 for i in range(lines)] for _ in range(columns)]

for i in range(columns):
    row_sum = 0
    print(f'{i+1} строка матрицы')
    for j in range(lines-1):
        matrix[i][j] = int(input('Введите число: '))
        row_sum += matrix[i][j]
    matrix[i][lines-1] = row_sum

for row in matrix:
    for item in row:
        print(f'{item:>3}', end='')
    print()
