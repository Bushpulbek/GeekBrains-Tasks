"""
В массиве случайных целых чисел поменять местами минимальный и максимальный элементы
"""
import random

array = random.sample(range(1, 100), 10)


def search_index(arr1):
    big = small = arr1[0]
    big_index = small_index = 0
    for i, item in enumerate(arr1):
        if item > big:
            big = item
            big_index = i
        elif item < small:
            small = item
            small_index = i
    return [small_index, big_index]


def swap(arr2, arr3):
    spam = arr2[arr3[0]]
    arr2[arr3[0]] = arr2[arr3[1]]
    arr2[arr3[1]] = spam
    return


print(f'Изначальный массив:\n{" ".join(map(str, array))}')
swap(array, search_index(array))
print(f'Изменённый массив:\n{" ".join(map(str, array))}')
