"""
Найти максимальный элемент среди минимальных элементов столбцов матрицы
"""
import random
size = 4
matrix = [random.sample(range(1, 10), size) for _ in range(size)]
smallest = []
biggest = 0

print('Матрица')
for row in matrix:
    for item in row:
        print(f'{item:>3}', end='')
    print()


for i in range(size):
    min_in_column = matrix[0][i]
    for j in range(size):
        if matrix[j][i] < min_in_column:
            min_in_column = matrix[j][i]
    smallest.append(min_in_column)

for i in smallest:
    if i > biggest:
        biggest = i

print(f'Наименьшие числа в столбцах:')
print(*smallest, sep=' ')
print(f'Максимальный элемент: {biggest}')
