"""
В одномерном массиве найти сумму элементов, находящихся между минимальным и максимальным элементами.
Сами минимальный и максимальный элементы в сумму не включать.
"""
import random
size = 10
arr = random.sample(range(1, 100), size)


def search_index(original):
    big = small = original[0]
    big_index = small_index = 0
    for i, item in enumerate(original):
        if item > big:
            big = item
            big_index = i
        elif item < small:
            small = item
            small_index = i
    return [small_index, big_index]


def find_sum(arr1, arr2):
    result = 0
    if arr2[0] < arr2[1]:
        for i in arr1[arr2[0]+1:arr2[1]]:
            result += i
    else:
        for i in arr1[arr2[1]+1:arr2[0]]:
            result += i
    return result


print("Массив:")
print(*arr, sep=" ")
print(f'Сумма между минимальным и максимальным элементом: {find_sum(arr, search_index(arr))}')
