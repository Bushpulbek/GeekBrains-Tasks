"""
Выполнить логические побитовые операции «И», «ИЛИ» и др. над числами 5 и 6.
Выполнить над числом 5 побитовый сдвиг вправо и влево на два знака
"""

logic_or = 5 | 6
logic_and = 5 & 6
logic_xor = 5 ^ 6
left_shift = 5 << 2
right_shift = 5 >> 2

print(f'Result of "|" operation: {logic_or}')
print(f'Result of "&" operation: {logic_and}')
print(f'Result of "^" operation: {logic_xor}')

print('Result of double left shifting of "5" is {}'.format(left_shift))
print('Result of double right shifting of "5" is {}'.format(right_shift))