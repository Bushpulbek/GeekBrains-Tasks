# Дерево
class Node:

    def __init__(self, data, weight):

        self.left = None
        self.right = None
        self.data = data
        self.weight = weight

    def insert_left(self, data, weight):
        if self.data:
            if self.left is None and isinstance(data, str):
                self.left = Node(data, weight)
            elif self.left is None and isinstance(data, Node):
                self.left = data
        else:
            self.data = data

    def insert_right(self, data, weight):
        if self.data:
            if self.right is None and isinstance(data, str):
                self.right = Node(data, weight)
            elif self.right is None and isinstance(data, Node):
                self.right = data
        else:
            self.data = data
    pass
