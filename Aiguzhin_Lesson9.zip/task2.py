"""
Закодируйте любую строку по алгоритму Хаффмана
"""
from collections import deque, Counter, OrderedDict
import tree


# Формирование дерева Хаффмана
def haffman_tree(freq_dict, arr) -> list:
    dict_copy = dict(freq_dict)
    arr_copy = list(arr)

    while len(arr_copy) > 1:
        weight = dict_copy[arr_copy[0]] + dict_copy[arr_copy[1]]
        knot = tree.Node(1, weight)
        knot.insert_left(arr_copy[0], dict_copy[arr_copy[0]])
        knot.insert_right(arr_copy[1], dict_copy[arr_copy[1]])

        del(dict_copy[arr_copy[0]])
        del(dict_copy[arr_copy[1]])
        dict_copy[knot] = weight
        arr_copy = list(queue_formation(dict_copy))

    return arr_copy


# Поиск по дереву Хаффмана (шифрование строки)
def haffman_encode(node: tree.Node, word, path='') -> None:
    if node.data == 1 and node.left:
        path += '0'
        haffman_encode(node.left, word, path)
        path = path[:-1]

    if node.data == 1 and node.right:
        path += '1'
        haffman_encode(node.right, word, path)
        path = path[:-1]

    if node.data != 1:
        word[node.data] = path

    return


# Поиск по дереву Хаффмана (расшифровка строки)
def haffman_decode(node: tree.Node, word, route) -> None:
    temp = node

    while len(route) != 0:
        if route[0] == '0' and temp.left:
            route = route[1:]
            temp = temp.left

        elif route[0] == '1' and temp.right:
            route = route[1:]
            temp = temp.right

        if not temp.left and not temp.right:
            word.append(temp.data)
            temp = node

    return


# Формируем очередь символов по возрастанию числа встречаемости
def queue_formation(freq) -> deque:
    arr = deque()
    sorted_t = sorted(freq.items(), key=lambda x: x[1])
    for j in sorted_t:
        arr.append(j[0])

    return arr


string = input('Введите строку: ')

table = Counter()
for i in string:
    table[i] += 1

array = queue_formation(table)

new_array = haffman_tree(table, array)
word_haffman = OrderedDict()
haffman_encode(new_array[0], word_haffman)

for key, values in word_haffman.items():
    print(f'Символ: "{key}", кодировка: {values}')

original_word = []
coded_word = word_haffman['b'] + word_haffman['p'] + word_haffman['!']
haffman_decode(new_array[0], original_word, coded_word)

print(original_word)
