"""
Определение количества различных подстрок с использованием хеш-функции. Пусть на вход функции дана строка.
Требуется вернуть количество различных подстрок в этой строке.
Примечания:
* в сумму не включаем пустую строку и строку целиком;
* задача считается решённой, если в коде использована функция вычисления хеша (любаяиз модуля hashlib)
"""
import hashlib


def rabin_karp(s:str, subs:str) -> str:
    assert len(s) > 0 and len(subs) > 0, "Отправлены пустые строки"
    assert len(s) >= len(subs), "Подстрока длинее строки"

    len_sub = len(subs)
    h_subs = hashlib.sha1(subs.encode('utf-8')).hexdigest()

    for i in range(len(s) - len_sub+1):
        if h_subs == hashlib.sha1(s[i:i + len_sub].encode('utf-8')).hexdigest():
            return h_subs


def count_subs(s:str) -> int:
    iteration = 0
    index = 1
    length = len(s)

    hashes, strings = set(), set()
    while iteration != length-1:
        for i in range(length-iteration):
            h1 = hashlib.sha1(s[i:i+index].encode('utf-8')).hexdigest()
            hashes.add(h1)
            strings.add(s[i:i+index])

        iteration += 1
        index += 1

    # Проверим наши подстроки алгоритмом Рабина-Карпа
    hashes_from_rk = set()
    for i in strings:
        hashes_from_rk.add(rabin_karp(s, i))
    # Хэши, полученные в нашем алгоритме должны совпасть с полученными из алгоритма Рабина-Карпа
    assert hashes == hashes_from_rk, "Ошибка хеэширования"

    return len(strings)


word = input("Введите строку: ")
result = count_subs(word)

print(f'Кол-во подстрок в строке "{word}" равно {result}')
