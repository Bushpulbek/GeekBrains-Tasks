"""
На вход подаётся число, вывести его в обратном порядке
"""
import cProfile
rec_result = []


# Рекурсивная функция
def rec_reverse(num):
    if (num % 10) == num:
        rec_result.append(num)
        return
    else:
        rec_result.append(num % 10)
        rec_reverse(num // 10)


# Итеративная функция
def reverse(num):
    result = []
    for i in range(len(str(num))):
        result.append(num % 10)
        num //= 10
    return result


# Код вывода получившегося числа:
"""
Для итеративного
arr = [str(item) for item in reverse(num)]
new_arr = ''.join(arr)
rev_int = int(new_arr)

Для рекурсивного
rec_reverse(num)
arr = [str(item) for item in rec_result]
new_arr = ''.join(arr)
rev_int = int(new_arr)
"""

# Timeit
"""
rec_reverse(52435541)
    1000 loops, best of 5: 2.48 usec per loop
rec_reverse(912876578908768901233463576653412567)
    1000 loops, best of 5: 15.5 usec per loop
rec_reverse(5678900987654355678901233764357949738481283920138092189312093898302198309)
    1000 loops, best of 5: 39.2 usec per loop
"""
"""
reverse(52435541)
    1000 loops, best of 5: 1.92 usec per loop
reverse(912876578908768901233463576653412567)
    1000 loops, best of 5: 8.78 usec per loop
reverse(5678900987654355678901233764357949738481283920138092189312093898302198309)
    1000 loops, best of 5: 31.4 usec per loop
"""

#cProfile
"""
cProfile.run('rec_reverse(52435541)')
    8/1    0.000    0.000    0.000    0.000 first_program.py:6(rec_reverse)
cProfile.run('rec_reverse(912876578908768901233463576653412567)')
    36/1    0.000    0.000    0.000    0.000 first_program.py:6(rec_reverse)
cProfile.run('rec_reverse(5678900987654355678901233764357949738481283920138092189312093898302198309)')
    73/1    0.000    0.000    0.000    0.000 first_program.py:6(rec_reverse)
"""
