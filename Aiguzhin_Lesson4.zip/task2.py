"""
Написать два алгоритма нахождения i-го по счёту простого числа.
Функция нахождения простого числа должна принимать на вход натуральное и возвращать соответствующее простое число.
Проанализировать скорость и сложность алгоритмов.
"""
# n - кол-во простых чисел
# num - номер простого числа


def sieve(n, num):
    arr = [i for i in range(n)]
    arr[1] = 0
    for i in range(2, n):
        if arr[i] != 0:
            j = i * 2

            while j < n:
                arr[j] = 0
                j += i

    result = [i for i in arr if i != 0]
    return result[num-1]


def prime(n, num):
    arr = [i for i in range(n)]
    arr[1] = 0
    result = []

    for i in arr[2:]:
        check = 1

        for j in arr[2:i]:
            if i % j == 0 and j != 1:
                check = 0
        if check == 1:
            result.append(i)

    return result[num-1]


"""
Скорость алгоритма "Решето Эратосфена" O(nlog(logn))
Док-во на Википедии
"simple.sieve(40,5)":
    1000 loops, best of 5: 9.77 usec per loop
"simple.sieve(100,5)"
    1000 loops, best of 5: 24 usec per loop
"simple.sieve(500,5)"
    1000 loops, best of 5: 152 usec per loop
"""
""" 
Скорость алгоритма O(n^2)
Всего действий для внешного цикла n-2. На каждом действии внешнего цикла совершается n-2 действий внутреннего цикла
Т.о. (n-2)(n-2) = n^2-4n+4 => O(n^2)
"simple.prime(40,5)":
    1000 loops, best of 5: 47.4 usec per loop
"simple.prime(100,5)"
    1000 loops, best of 5: 286 usec per loop
"simple.prime(500,5)"
    1000 loops, best of 5: 7.03 msec per loop
"""
