"""
Написать программу, которая будет складывать, вычитать, умножать или делить два числа
"""
import sys

while True:
    num1 = int(input("Введите первое число: "))
    op = (input("Введите знак операции: "))
    while op != '0' and op != '+' and op != '-' and op != '*' and op != '/':
        print("Ошибка ввода")
        op = (input("Введите знак операции: "))
    if op == '0':
        break
    num2 = int(input("Введите второе число: "))
    if op == '+':
        print(f'{num1 + num2}\n')
    elif op == '-':
        print(f'{num1 - num2}\n')
    elif op == '*':
        print(f'{num1 * num2}\n')
    else:
        while num2 == 0:
            print("На 0, к сожалению, делить нельзя")
            num2 = int(input("Введите второе число: "))
        print(f'{num1/num2}\n')


"""
Подсчитать, сколько было выделено памяти под переменные в программах, 
разработанных на первых трёх уроках.

sys.version: 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 19:29:22) [MSC v.1916 32 bit (Intel)]
sys. platform: win32

Код:
    total = 0

    for var in dir():   # dir() возвращает отсортированный список строк c именами, определенными в модуле
        if var.startswith("__"):
            pass
        else:
            total += sys.getsizeof(var)

    print(f'Memory consumed: {sys.getsizeof(total) + total}')

Память, выделенная на переменные:
157 байта.

Изменяя условия в цикле можно посчитать память выделенную на определённую переменную
"""
