"""
Найти максимальный элемент среди минимальных элементов столбцов матрицы
"""
import random
import sys

size = 4
matrix = [random.sample(range(1, 10), size) for _ in range(size)]
smallest = []
biggest = 0

print('Матрица')
for row in matrix:
    for item in row:
        print(f'{item:>3}', end='')
    print()


for i in range(size):
    min_in_column = matrix[0][i]
    for j in range(size):
        if matrix[j][i] < min_in_column:
            min_in_column = matrix[j][i]
    smallest.append(min_in_column)

for i in smallest:
    if i > biggest:
        biggest = i

print(f'Наименьшие числа в столбцах:')
print(*smallest, sep=' ')
print(f'Максимальный элемент: {biggest}')


"""
Подсчитать, сколько было выделено памяти под переменные в программах, 
разработанных на первых трёх уроках.

sys.version: 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 19:29:22) [MSC v.1916 32 bit (Intel)]
sys. platform: win32

Код:
    total = 0

    for var in dir():   # dir() возвращает отсортированный список строк c именами, определенными в модуле
        if var.startswith("__"):
            pass
        else:
            total += sys.getsizeof(var)

    print(f'Memory consumed: {sys.getsizeof(total) + total}')

Память, выделенная на переменные:
375 байт.

Изменяя условия в цикле можно посчитать память выделенную на определённую переменную
"""
