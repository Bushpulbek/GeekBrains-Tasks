"""
Пользователь вводит данные о количестве предприятий,
их наименования и прибыль за четыре квартала для каждого предприятия.
Программа должна определить среднюю прибыль (за год для всех предприятий) и отдельно вывести наименования предприятий,
чья прибыль выше среднего и ниже среднего.
"""
from collections import defaultdict, OrderedDict
from statistics import mean

money = []
data = defaultdict(int)

factories_amount = int(input("Введите количество предприятий: "))


for i in range(factories_amount):
    name = input(f"Введите название {i+1} предприятия: ")
    income = int(input("Прибыль за четыре квартала составила: "))
    data[name] += income

money = data.values()
average = mean(money)


print("Предприятия с прибылью ниже среднего: ")
for key, value in data.items():
    if value < average:
        print(key, end=' ')
print()
print("Предприятия с прибылью выше среднего: ")
for key, value in data.items():
    if value > average:
        print(key, end=' ')
print()
