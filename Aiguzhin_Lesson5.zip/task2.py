"""
Написать программу сложения и умножения двух шестнадцатеричных чисел.
При этом каждое число представляется как массив, элементы которого — цифры числа.
"""
from collections import*

all_digits = OrderedDict({str(i): i for i in range(10)})
all_digits.update({'A': 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15})

first_number = list(input("Введите первое число: "))
second_number = list(input("Введите второе число: "))

# Для удобства поменяем числа местами
if len(first_number) < len(second_number):
    first_number, second_number = second_number, first_number

first_length = len(first_number)
second_length = len(second_number)

first_number = first_number[::-1]
second_number = second_number[::-1]
result = deque()
digit = 0   # Если превысим разряд числа, то digit = 1 для учёта в последующей операции


for i in range(second_length):
    one = first_number[i]
    two = second_number[i]
    three = all_digits[one] + all_digits[two]
    if digit == 0:
        result.appendleft(three)
    elif digit == 1:
        result.appendleft(three + digit)
    if three >= 16:
        digit = 1

# Если остались числа, то продолжаем складывать оставшиеся числа большего числа
if len(result) != first_length:
    for i in range(first_length - len(result)):
        value = all_digits[first_number[len(result)+i]]
        result.appendleft(value + digit)
        if value + digit >= 16:
            digit = 1
        else:
            digit = 0

# Все разрядные переходы были учтены в двух циклах выше
# Для удобства приведём, где требуется, обратно, к значениям нашего словаря
for i in range(len(result)):
    if result[i] >= 16:
        result[i] -= 16

result = [key for j in result for key, value in all_digits.items() if j == value]
print(result)
