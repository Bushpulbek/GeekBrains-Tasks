"""
Отсортируйте по убыванию методом пузырька одномерный целочисленный массив,
заданный случайными числами на промежутке [-100; 100).
Выведите на экран исходный и отсортированный массивы
"""
import random

size = int(input("Введите размер массива: "))
array = [random.randint(-100, 99) for _ in range(size)]


def bubble_sort(arr):
    for i in range(size-1):
        for j in range(size-1):
            if arr[j] < arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return


print(f'Изначальный массив:\n{array}')
bubble_sort(array)
print(f'Отсортированный массив:\n{array}')
