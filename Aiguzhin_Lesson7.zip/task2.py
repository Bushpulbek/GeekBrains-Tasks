"""
 Отсортируйте по возрастанию методом слияния одномерный вещественный массив,
 заданный случайными числами на промежутке [0; 50).
 Выведите на экран исходный и отсортированный массивы.
"""
import random

size = int(input("Введите размер массива: "))
array = [random.uniform(0, 49) for _ in range(size)]


def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    middle = len(arr) // 2
    arr_left = merge_sort(arr[0:middle])
    arr_right = merge_sort(arr[middle:])

    result = []
    i, j = 0, 0
    for k in range(len(arr)):
        if arr_left[i] < arr_right[j]:
            result.append(arr_left[i])
            i += 1
        else:
            result.append(arr_right[j])
            j += 1

        if i >= len(arr_left):
            result.extend(arr_right[j:])
            break
        elif j >= len(arr_right):
            result.extend(arr_left[i:])
            break

    return result


print(f'Изначальный массив:\n{array}')
print(f'Отсортированный массив:\n{merge_sort(array)}')
