"""
Массив размером 2m + 1, где m — натуральное число, заполнен случайным образом. Найдите в массиве медиану.
Медианой называется элемент ряда, делящий его на две равные части: в одной находятся элементы,
которые не меньше медианы, в другой — не больше медианы.
"""
import random

size = int(input("Введите число от 1 до 5: "))
size = 2 * size + 1

array = [random.randint(-50, 50) for _ in range(size)]


# Находит большй элемент в переданном массиве и ставит его в начало
def heapify(arr, n, i):
    largest = i  # Инициализируем индекс корня как больший
    left = 2 * i + 1
    right = 2 * i + 2

    if left < n and arr[i] < arr[left]:
        largest = left

    if right < n and arr[largest] < arr[right]:
        largest = right

    # Меняем корень
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]

        # Heapify the root.
        heapify(arr, n, largest)


# Сортировка кучей / Пирамидальная сортировка
def heapSort(arr):
    n = len(arr)

    # Находим больший элемент
    for i in range(n, -1, -1):
        heapify(arr, n, i)

    # Двигаясь по массиву, переставляем большие элементы в конец
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]  # swap
        heapify(arr, i, 0)


def median(arr):
    heapSort(arr)
    if len(arr) % 2 == 1:
        return arr[len(arr) // 2]
    else:
        return 0.5 * (arr[len(arr) / 2 - 1] + arr[len(arr)/ 2])


print(f'Изначальный массив: {array}')
print(f'Медиана: {median(array)}')
print(f'Отсортированный массив: {array}')
